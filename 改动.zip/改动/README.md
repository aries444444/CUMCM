# 改动汇总（2026-09-13）

本文件夹汇总本轮「**代码去重 + 全部源程序进附录**」所涉及的全部文件，目录结构与原工程一致，
可直接整体覆盖回原位置（或单独查看/对比）。

## 一、新增文件

| 文件 | 位置 | 说明 |
|---|---|---|
| `common.py` | `ProblemFolder/` | **公共数值内核**：附件定位与读入、三角求解（纯 Python 追赶法 / LAPACK 带状两种等价实现）、守恒型有限体积 Crank–Nicolson 单步（固定半径 `crank_radial`、随体坐标 `crank_zeta`）、交错 Picard 耦合步 `picard_step`、烘干时长事件求根 `integrate_until_dry`。四个求解器共用，全文只实现一次。 |
| `附录源程序.tex` | `ProblemFolder/` | **完整源程序附录正文**（9 个程序、1256 行），由 `build_appendix.py` 自动生成，供 `A题论文.tex` 用 `\input{附录源程序}` 引入。 |
| `build_appendix.py` | 工程根目录 | 附录生成脚本：读取 `ProblemFolder/` 下的源程序并生成上述附录，改代码后重跑即可同步，**附录与代码永远逐字一致**。 |

## 二、修改文件

| 文件 | 改动要点 |
|---|---|
| `q1_solver.py` | 删除内嵌的 `_annex` / `thomas` / `crank_step`，改用 `common`；保留 `crank_step` 同名薄封装以兼容 `verify_q1.py`。 |
| `q2_solver.py` | 同上；`step()` 改为调用 `common.picard_step`。 |
| `q3_solver.py` | 同上；`run_drying()` 的推进循环改用 `common.integrate_until_dry`（t* 事件求根收敛到一处）。 |
| `q4_solver.py` | 同上；`run4()` 同样改用 `integrate_until_dry`，`crank_step` 转调 `crank_zeta`。 |
| `q78_sensitivity.py` | 同上；`run_case()` 改用 `picard_step` + `integrate_until_dry`。 |
| `q3_shrink_solver.py` | 去掉重复内核，改用 `common`（原为早期消融对照脚本）。 |
| `verify_q1.py`、`verify_q3.py`、`verify_q4.py` | 控制台 UTF-8 初始化改调 `common.setup_console()`。 |
| `A题论文.tex` | ① 首行加 `% !TeX program = xelatex`（附录含中文注释代码，**必须 XeLaTeX 编译**）；② 导言区补 `listings`、`xcolor` 与代码样式 `\lstset`；③ 附录顺序调整为「正文 → 参考文献 → 附录（AI 声明 / 支撑材料清单 / 源程序）」，源程序用 `\input{附录源程序}` 引入；④ 支撑材料清单补入 `common.py` 并说明模块结构。 |
| `附录代码片段.tex`（根目录） | 原「核心片段」文件重写为**独立预览外壳**：编译它即可单独查看完整附录，正文与论文共用同一份 `ProblemFolder/附录源程序.tex`，不再有需要手工同步的第二份副本。 |
| `q1_out.txt`、`q2_out.txt` | 用复算输出刷新（原文件是更早版本的旧日志，与论文表 1–表 4 不一致）。 |

## 三、未纳入本文件夹的文件

| 文件 | 原因 |
|---|---|
| `ProblemFolder/支撑材料/*.py`（9 个） | 已同步为与本文件夹 `ProblemFolder/` 下**完全相同**的内容，无需重复存放。 |
| `ProblemFolder/result1.xlsx`、`result2.xlsx` | 复算后与原件**逐格完全一致**（0 差异），内容未变。 |
| `ProblemFolder/result3.xlsx`、`result4.xlsx` | 未重新生成（改动经逐位对拍证明与旧代码等价，结果不变）。 |

## 四、等价性验证结论（本次改动的正确性依据）

- q1：重算 `result1.xlsx` ↔ 改动前产物 **1801 行 × 2 表，0 个单元格差异**；
- q2：重算 `result2.xlsx` ↔ 改动前产物 **10801 行 × 2 表，0 个单元格差异**；
- q3 / q4 / q78：与改动前代码做 1500 步逐位探针对拍，结果 **IDENTICAL**（逐位相同）。

即：**重构只消除重复，未改变任何数值结果**。

## 五、复现方式

```powershell
cd ProblemFolder
python q1_solver.py          # 问题 1（约 8 min）
python q2_solver.py          # 问题 2
python q3_solver.py          # 问题 3（较慢）
python q4_solver.py          # 问题 4
python q78_sensitivity.py    # 表 7 消融 + 表 8 灵敏度
python verify_q1.py          # 表 2 逐格离散差定位
cd ..
python build_appendix.py     # 重新生成附录正文
xelatex A题论文.tex          # 编译论文（ProblemFolder 下，需 XeLaTeX）
```
