# -*- coding: utf-8 -*-
"""2026 CUMCM A 题 问题4 求解器（含收缩）
附录4 经验式（物性随 C、T 变），热质双向耦合，交错 Picard + Crank--Nicolson。
公共数值内核（附件读取、三对角求解、zeta 系 CN 单步、Picard 步）见 common.py。
收缩：附件2 半径 R(t)（Pchip 插值），拉格朗日坐标 zeta = r/R(t) 随物料变形，
      菲克/傅里叶定律相对固相骨架，zeta 系中无对流项：
      dC/dt = 1/(R^2 zeta) d(zeta D dC/dzeta)/dzeta，
      rho c_p dT/dt = 1/(R^2 zeta) d(zeta k dT/dzeta)/dzeta（d/dt 为固定 zeta 的随体导数）。
主离散：Δζ=1/160（161 节点），Δt=5 s。
  依据：1/40 离散 6 h 行误差约 1.6e-4，1/80 约 5.4e-5（Richardson），仍未低于四位小数
  对应的 0.5e-4 阈值，故生产离散加密至 1/160。
迭代：T、C 无穷范数相对变化 < 1e-8 停止（上限 20 轮）；系数取迭代最新可用层，R 取半步中点。
事件时间：g(t)=max C(r,t)-0.15 在相邻时间层间线性插值求根（见 common.integrate_until_dry）。
输出：表6（每 6 h x 0/0.5/1/1.5/2 cm + 表面，域外记 '-'）+ result4.xlsx（每 60 s，22 列）。
固定物理距离列用 Pchip 插值（见 interp_dist 依据）。
验证：V1 动边界质量守恒（含压缩项 2R'/R ∫C r dr）、V2 时间收敛、V3 ζ 离散五点链（至 1/320）、V4 渐近。
"""
import os
import numpy as np
import openpyxl
from scipy.interpolate import PchipInterpolator

from common import (ROOT, crank_zeta, integrate_until_dry, kernel,
                    load_annex, picard_step, setup_console)

setup_console()

R0, T0, C0 = 0.02, 28.0, 2.55
h, hm = 25.0, 8e-7
TEND, CEND = 50.165, 0.04986        # 附件1 末值（恒温干燥段）
DZ, NZ = 1.0 / 160.0, 161           # ζ 主离散 161 节点
zeta = np.arange(NZ) * DZ

# 附录4 经验式（C<0.02 时取 0.02，仅为数值保险：物理解 C >= C_air=0.04986）
rho4 = lambda C: 760.0 + 90.0 * C
cp4 = lambda C: 1850.0 + 2150.0 * C / (C + 1.0)
k4 = lambda C: 0.12 + 0.20 * C / (C + 1.0)
D4 = lambda C, T: 4.2e-4 * np.exp(-0.30 / np.maximum(C, 0.02)) * np.exp(-3850.0 / T)  # T 开尔文

d1 = load_annex('附件1.xlsx')
T_air = lambda t: np.interp(t, d1[:, 0], d1[:, 1]) if t <= 14400 else TEND
C_air = lambda t: np.interp(t, d1[:, 0], d1[:, 2]) if t <= 14400 else CEND

d2 = load_annex('附件2.xlsx')
T2END = d2[-1, 0]; REND = d2[-1, 1] / 100.0    # 259200 s 后半径保持 1.198 cm（附件2 单位为 cm）
_Rp = PchipInterpolator(d2[:, 0], d2[:, 1] / 100.0, extrapolate=False)
RofT = lambda t: _Rp(t) if t <= T2END else REND
_Rpd = _Rp.derivative()
RpofT = lambda t: float(_Rpd(t)) if t <= T2END else 0.0

def interp_dist(C, R, dj):
    """固定物理距离 dj 处的浓度：在 ζ=dj/R 处用 Pchip（三次 Hermite、保单调）插值。
    依据：C(ζ) 为抛物方程的光滑解（无激波），三次插值误差 O(Δζ^3)，远小于线性插值的
    O(Δζ^2)；后者在 30 h 前后的陡梯度区已主导表 6 行差（1/80→1/160 实测 1.58e-4，
    与线性插值误差估计同量级，导致收敛比仅 2.5 而非 4），故输出与收敛检验统一改用 Pchip。"""
    return float(PchipInterpolator(zeta, C)(dj / R))

def crank_step(u, K, Cp, R, beta, bc_prev, bc_next, dt):
    """zeta 系 Crank--Nicolson 一步（物料随体坐标，无对流项；见 common.crank_zeta）。
    beta：表面 Robin 系数（热 h*R/k_s；质 h_m*R/D_s）。"""
    return crank_zeta(u, K, Cp, beta, bc_prev, bc_next, dt, NZ, DZ, R)

def step(T, C, t_prev, t_cur, dt):
    """一个时间步：R、R' 取半步中点，交错 Picard 耦合步。"""
    R = RofT(0.5 * (t_prev + t_cur))
    crk = kernel('zeta', dt, NZ, DZ)
    return picard_step(crk, T, C, dt, t_prev, t_cur,
                       rho4, cp4, k4, D4, T_air, C_air, h * R, hm * R)

def water_int(C, R):
    """W = Σ v_i C_i（随体域离散控制体体积积分，v_i 与 crank_zeta 一致）。"""
    v = np.zeros(NZ); v[0] = DZ ** 2 / 8
    v[1:NZ - 1] = zeta[1:NZ - 1] * DZ
    v[NZ - 1] = (1.0 - ((NZ - 1.5) * DZ) ** 2) / 2.0
    return R * R * (C * v).sum()

def run4(dzg, Nzg, dt, write_files=True):
    """全程求解直至 max C <= 0.15（t* 事件求根）。返回
    (tstar, tab6, rows4, iters, rels, hist, nstar, Cstar)；tab6 末行为 t* 处插值状态。"""
    global NZ, DZ, zeta
    NZ, DZ, zeta = Nzg, dzg, np.arange(Nzg) * dzg
    T, C = np.full(NZ, T0), np.full(NZ, C0)
    dist = np.array([0.0, 0.005, 0.01, 0.015, 0.02])     # 表6 固定距离列（m）
    xlsx_d = np.arange(0.0, 0.02001, 0.001)             # result4 0:0.1:2 cm（m）
    tab6, rows4 = [], []
    Whist, Cshist, Rhist, Rphist = [], [], [], []
    iters, rels = [], []

    def one_step(T, C, t_prev, t_cur):
        T, C, it, rel = step(T, C, t_prev, t_cur, dt)
        iters.append(it); rels.append(rel)
        return T, C

    def record(n, t, T, C):
        R = RofT(t); Rp = RpofT(t)
        Whist.append(water_int(C, R))                   # 动边界守恒检验用历史量
        Cshist.append(C[-1]); Rhist.append(R); Rphist.append(Rp)
        if n % (21600 // dt) == 0:                      # 每 6 h 记表6 一行
            tab6.append([interp_dist(C, R, dj) if dj <= R else np.nan for dj in dist]
                        + [C[-1]])
        if write_files and n % (60 // dt) == 0:         # 每 60 s 记 result4 一行
            rows4.append((t, [interp_dist(C, R, dj) if dj <= R else None for dj in xlsx_d]
                          + [C[-1]]))

    tstar, _, Cstar, nstar = integrate_until_dry(one_step, T, C, dt, record=record)
    R = RofT(tstar)
    tab6.append([interp_dist(Cstar, R, dj) if dj <= R else np.nan for dj in dist] + [Cstar[-1]])
    if write_files:
        rows4.append((tstar, [interp_dist(Cstar, R, dj) if dj <= R else None for dj in xlsx_d]
                      + [Cstar[-1]]))
    return tstar, np.array(tab6), (rows4 if write_files else None), \
        np.array(iters), np.array(rels), (Whist, Cshist, Rhist, Rphist), nstar, Cstar

if __name__ == "__main__":
    # ================= 问题4：Δζ=1/160，dt=5 s，直到 max C <= 0.15 =================
    DT = 5.0
    tstar, tab6, rows4, iters, rels, hist, nstar, Cstar = run4(1.0 / 160.0, 161, DT)
    R = RofT(tstar)
    print('问题4 烘干时长: t* = %.3f s = %.4f h (max C = %.6f, 此时 R = %.4f cm)'
          % (tstar, tstar / 3600, Cstar.max(), R * 100))
    print('Picard 统计: 平均 %.2f 轮，最大 %d 轮，退出残差 中位 %.2e / 最大 %.2e'
          % (iters.mean(), iters.max(), np.median(rels), rels.max()))
    np.set_printoptions(precision=4, suppress=True)
    print('表6 水分浓度 (kg/kg)，行=6,12,...h 直至 t*，列=0/0.5/1/1.5/2 cm + 表面:')
    for k, row in enumerate(tab6):
        rr = ' '.join('  --' if np.isnan(v) else '%6.4f' % v for v in row)
        trow = (k + 1) * 6.0 if k + 1 < len(tab6) else tstar / 3600.0
        print('%7.1fh |%s' % (trow, rr))

    wb = openpyxl.Workbook()
    ws = wb.active; ws.title = 'Sheet1'
    ws.cell(1, 1, '时间\\到药材中心的距离')
    xlsx_d = np.arange(0.0, 0.02001, 0.001)
    for j in range(len(xlsx_d)):
        ws.cell(1, 2 + j, round(xlsx_d[j] * 100, 1))
    ws.cell(1, 2 + len(xlsx_d), '药材表面')
    for k, (tt, row) in enumerate(rows4):
        ws.cell(2 + k, 1, round(tt, 1))
        for j, v in enumerate(row):
            if v is not None:
                ws.cell(2 + k, 2 + j, round(v, 4))
    wb.save(os.path.join(ROOT, 'result4.xlsx'))
    print('已写出 result4.xlsx（%d 行）' % len(rows4))

    # ================= 验证 =================
    Whist, Cshist, Rhist, Rphist = hist
    # V1 动边界质量守恒: d/dt ∫C r dr = 2R'/R·∫C r dr - R·h_m(C_s-C_air)
    _NZ_save, _DZ_save, _zeta_save = NZ, DZ, zeta
    NZ, DZ, zeta = 161, 1.0 / 160.0, np.arange(161) * (1.0 / 160.0)
    W0 = water_int(np.full(NZ, C0), R0)
    NZ, DZ, zeta = _NZ_save, _DZ_save, _zeta_save
    lhs = Whist[-1] - W0
    tt = np.arange(1, nstar + 1) * DT
    f1 = [2 * rp / r * w for rp, r, w in zip(Rphist, Rhist, Whist)]
    f2 = [-r * hm * (cs - C_air(t)) for r, cs, t in zip(Rhist, Cshist, tt)]
    rhs = np.trapezoid([a + b for a, b in zip(f1, f2)], tt)
    print('验证V1 离散守恒: ΣvΔC = %.6e，∫[2R\'/R·W - R h_m(C_R-C_air)]dt = %.6e，差 %.2e'
          % (lhs, rhs, lhs - rhs))

    # V2 时间收敛: 前 6 h，dt=5 vs 2.5（同一离散 1/160）
    def run6h(dt):
        T, C = np.full(NZ, T0), np.full(NZ, C0)
        for n in range(1, int(21600 / dt) + 1):
            T, C, it, rel = step(T, C, (n - 1) * dt, n * dt, dt)
        R = RofT(21600)
        dist = np.array([0.0, 0.005, 0.01, 0.015, 0.02])
        row = [interp_dist(C, R, dj) if dj <= R else np.nan for dj in dist] + [C[-1]]
        return np.array(row)
    r5 = run6h(5.0); r25 = run6h(2.5)
    print('验证V2 时间收敛(6h 行): dt=5 vs 2.5 最大差 %.2e' % np.nanmax(np.abs(r5 - r25)))

    # V3 ζ 空间收敛五点链: 1/20, 1/40, 1/80, 1/160, 1/320（同 dt=5 s）
    ts = []; t6s = []
    for dzg, nzg in ((1.0 / 20, 21), (1.0 / 40, 41), (1.0 / 80, 81),
                     (1.0 / 160, 161), (1.0 / 320, 321)):
        t_, tab_, _, it_, rl_, _, _, _ = run4(dzg, nzg, DT, write_files=False)
        ts.append(t_); t6s.append(tab_)
        print('V3 链 Δζ=1/%d: t* = %.4f h (%d s), 平均 %.2f 轮'
              % (nzg - 1, t_ / 3600, round(t_), it_.mean()))
    th = [t / 3600.0 for t in ts]
    dd1, dd2, dd3, dd4 = th[1] - th[0], th[2] - th[1], th[3] - th[2], th[4] - th[3]
    p12, p23, p34 = np.log2(dd1 / dd2), np.log2(dd2 / dd3), np.log2(dd3 / dd4)
    ext = th[4] + dd4 / (2 ** p34 - 1.0)
    print('V3 实测收敛阶: p12=%.3f (1/20->1/40->1/80), p23=%.3f (1/40->1/80->1/160),'
          ' p34=%.3f (1/80->1/160->1/320)' % (p12, p23, p34))
    print('V3 按实测阶外推: t* = %.4f h；最细两档差 = %.4f h；外推-最细 = %.4f h'
          % (ext, dd4, ext - th[4]))
    dab = np.nanmax(np.abs(t6s[2][:-1] - t6s[3][:-1]))
    dbc = np.nanmax(np.abs(t6s[3][:-1] - t6s[4][:-1]))
    print('V3 表6 对齐行最大差: 1/80->1/160: %.2e, 1/160->1/320: %.2e kg/kg' % (dab, dbc))
    print('V3 表6 末行差(1/160 vs 1/320): %.2e kg/kg（t* 差 %.4f h）'
          % (np.nanmax(np.abs(t6s[3][-1] - t6s[4][-1])), th[4] - th[3]))

    # V4 渐近: 常数边界，长时程（R 仍按附件2 收缩并保持 1.198 cm）
    NZ, DZ, zeta = 161, 1.0 / 160.0, np.arange(161) * (1.0 / 160.0)
    T, C = np.full(NZ, T0), np.full(NZ, C0)
    for n in range(1, int(2.5e5 / DT) + 1):
        T, C, it, rel = step(T, C, (n - 1) * DT, n * DT, DT)
        if n * DT in (50000, 150000, 250000):
            print('验证V4 渐近: t=%ds 中心 T=%.4f (目标 %.4f)，表面 C=%.5f (目标 %.5f)，R=%.4f cm'
                  % (n * DT, T[0], TEND, C[-1], CEND, RofT(n * DT) * 100))
